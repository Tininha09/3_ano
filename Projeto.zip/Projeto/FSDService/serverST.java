import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.io.*;


public class serverST {
    static ArrayList<Service> servicesAvailable = new ArrayList<Service>(); 



    public static void main (String[] args) throws IOException{

        if(args.length != 1){
            System.out.println("Parameters missing");
            System.exit(1);

        }
        int port = Integer.valueOf(args[0]);


        ServerSocket servidor = null;

        servidor = new ServerSocket(port);
        
        System.out.println("Servidor a correr:");

        while(true){
        try {

            Socket ligacao = servidor.accept();           
            HandlerST handler = new HandlerST(ligacao, servicesAvailable);
            handler.start();
            

            
        } catch (IOException e){
            System.out.println("Erro na execucao do servidor: " +e);
            System.exit(1);
        }

        }
    }








}
