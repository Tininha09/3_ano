
import java.net.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.io.*;
import java.util.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.StringTokenizer;
import java.util.TimeZone;

public class HandlerST extends Thread {
    Socket ligacao;
	BufferedReader in;
	PrintWriter out;
	ArrayList<Service> servicesAvailable;
	private static final Charset UTF_8 = StandardCharsets.UTF_8;






    public HandlerST(Socket ligacao, ArrayList<Service> servicesAvailable) {
		this.ligacao = ligacao;
		this.servicesAvailable = servicesAvailable;
		try
		{	
			this.in = new BufferedReader (new InputStreamReader(ligacao.getInputStream()));
			
			this.out = new PrintWriter(ligacao.getOutputStream());
		} catch (IOException e) {
			System.out.println("Erro na execucao do servidor: " + e);
			System.exit(1);
		}
	}
	
	public void run() {  
		String message = "";              
		try {
			System.out.println("Aceitou ligacao de cliente no endereco " + ligacao.getInetAddress() + " na porta " + ligacao.getPort());
			String info = in.readLine();
		

            String[] res = info.split("[,]", 0);


			//GET RESPONSE DEPENDING ON USER REQUEST
			if (res[0].equals("registerService")){
				message = registarServico(res);
				out.println(message);

			}


			if (res.length==3 && res[2].equals("Verify_Hash")){
				message = verifyHash(res);
				out.println(message);

			}

			if (res[0].equals("getServicesSocket")){

				if (servicesAvailable.size() != 0){

				for(int i=0; i< servicesAvailable.size(); i++){

					if (servicesAvailable.get(i).getTecnologia().equals("Java Sockets")){

								
				message = (servicesAvailable.get(i).getDescription()+";"+servicesAvailable.get(i).getKeyRegister()+";"+servicesAvailable.get(i).getIpService()+";"+servicesAvailable.get(i).getPorta()+";"+ getTimeStamp());

				out.println(message);
				} 
			}
		} else out.println("Nao existem servicos registados");
			}

			if (res[0].equals("getServicesRMI")){

				if (servicesAvailable.size() != 0){
				for(int i=0; i< servicesAvailable.size(); i++){
					if (servicesAvailable.get(i).getTecnologia().equals("Java RMI") && servicesAvailable.size() != 0){
				//message = (servicesAvailable.get(i).getDescription() + " - "+ servicesAvailable.get(i).getDescription()+";"+servicesAvailable.get(i).getKeyRegister()+";"+servicesAvailable.get(i).getIpService()+";"+servicesAvailable.get(i).getPorta()+";"+ servicesAvailable.get(i).getNomeServiceRMI()+";"+ getTimeStamp());
						message = servicesAvailable.get(i).getDescription() +";"+servicesAvailable.get(i).getKeyRegister()+";"+servicesAvailable.get(i).getIpService()+";"+servicesAvailable.get(i).getPorta()+";"+ servicesAvailable.get(i).getNomeServiceRMI()+";"+ getTimeStamp();
				out.println(message);

				}
			}
		} else out.println("Nao existem servicos registados");
			}
            

			out.flush();
			in.close();
			out.close();
			ligacao.close();

		} catch (IOException e) {
			System.out.println("Erro na execucao do servidor: " + e);
			System.exit(1);
		}
	}

	public String registarServico (String[] res){
		Service servico = null;

		if (res[3].equals("Java RMI")){

            servico = new Service(res[1],res[2],res[3],res[4],res[5],res[6]);

            }else if (res[3].equals("Java Sockets")){
                servico = new Service(res[1],res[2],res[3],res[4],res[5],null);
            }

			if (!existe(servico.getKeyRegister())){
				servicesAvailable.add(servico);
				System.out.print(servico.getDescription());
				return " Servico Registado com Sucesso ! ";

			}
				else {
				   getService(servico.getKeyRegister()).setDescription(servico.getDescription());
				   System.out.print(servico.getDescription());
				   return " Servico Atualizado com Sucesso ! ";

				}


	}

	public String verifyHash(String[] args){
		System.out.println(args[0]+args[1]+args[2]);
		String id_raw = args[0];
		byte[] md5InBytes = MD5Utils.digest(id_raw.getBytes(UTF_8));
		String id = MD5Utils.bytesToHex(md5InBytes);
		String hash = args[1];
		System.out.println(hash + id + hash.equals(id));

		if (hash.equals(id)) {


			return "true";
		}else return "false";
	}

	public String getTimeStamp (){
		TimeZone tz = TimeZone.getTimeZone("UTC");
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'"); // Quoted "Z" to indicate UTC, no timezone offset
		df.setTimeZone(tz);
		String nowAsISO = df.format(new Date());

		return nowAsISO;
	}
    








	        //Modificadores
			public void setListaServicos(ArrayList<Service> servicesAvailable) {
				this.servicesAvailable = servicesAvailable;
			}
	
	
				//Seletores
		public ArrayList<Service> getListaServicos() {
			return new ArrayList<> (servicesAvailable);
		}
			  
		  //existe Servico
	
		  public boolean existe (String registerKey){
			if (registerKey.isEmpty()){
				throw new NullPointerException("O parâmetro 'RegisterKey' encontra-se em branco");
			}else {
			for (Service a: servicesAvailable){
				if (a.getKeyRegister().equals(registerKey)){
					return true;
				} 
			}
			return false;
		}}
	
			//Retorna um serviço pretendido dando o seu registerkey
			public Service getService(String registerKey){
				for(Service s: servicesAvailable){
					if(s.keyRegister.equals(registerKey)){
						return s;
					}
				}
				return null;
			}
}
