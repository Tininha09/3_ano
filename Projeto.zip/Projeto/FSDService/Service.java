public class Service {
    String keyRegister;
    String description;
    String tecnologia;
    String ipService;
    String porta;
    String nomeServiceRMI; 

    public Service(String keyRegister, String description, String tecnologia, String ipService, String porta, String nomeServiceRMI) {
        this.keyRegister = keyRegister;
        this.description = description;
        this.tecnologia = tecnologia;
        this.ipService = ipService;
        this.nomeServiceRMI = nomeServiceRMI;
        this.porta = porta;
    }

    public String getKeyRegister() {
        return keyRegister;
    }

    public void setKeyRegister(String keyRegister){
        this.keyRegister= keyRegister;
    }

    public String getPorta() {
        return porta;
    }

    public void setPorta(String porta){
        this.porta= porta;
    }

    public void setKeyRegisterSocket(String ip, String porto) {
        this.keyRegister = ip+porto;
    }

    public void setKeyRegisterRMI(String ip, String porto, String nome) {
        this.keyRegister = ip+porto+nome;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTecnologia() {
        return tecnologia;
    }

    public void setTecnologia(String tecnologia) {
        this.tecnologia = tecnologia;
    }

    public String getIpService() {
        return ipService;
    }

    public void setIpService(String ipService) {
        this.ipService = ipService;
    }

    public String getNomeServiceRMI() {
        return nomeServiceRMI;
    }

    public void setNomeServiceRMI(String nomeServiceRMI) {
        this.nomeServiceRMI = nomeServiceRMI;
    }
    
    
    
}
