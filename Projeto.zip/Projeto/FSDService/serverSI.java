import java.net.*;
import java.io.*;



public class serverSI {
    static int DEFAULT_PORT;
    static String ip_Ticketing;
    static String porta_Ticketing;


    public static void main (String[] args) throws IOException{



        if(args.length != 3){
            System.out.println("Parameters missing");
            System.exit(1);

        }

        int port = Integer.valueOf(args[0]);

        ip_Ticketing = args[1];
        porta_Ticketing = args[2];





        ServerSocket servidor = null;

        servidor = new ServerSocket(port);
        
        System.out.println("Servidor a correr:");

        while(true){
        try {

            Socket ligacao = servidor.accept();


            
            HandlerSI handler = new HandlerSI(ligacao, ip_Ticketing, porta_Ticketing);
            handler.start();
            

            
        } catch (IOException e){
            System.out.println("Erro na execucao do servidor: " +e);
            System.exit(1);
        }

        }
    }
    
}



