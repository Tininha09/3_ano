import java.net.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.io.*;
import java.util.*;


public class HandlerSI extends Thread {
	Socket ligacao;
	BufferedReader in;
	PrintWriter out;
	private static final Charset UTF_8 = StandardCharsets.UTF_8;
	private static final String OUTPUT_FORMAT = "%-20s:%s";
	String ip_Ticketing ="";
	String porta_Ticketing = "";

   




    public HandlerSI(Socket ligacao, String ip_Ticketing, String porta_Ticketing) {

		this.ip_Ticketing= ip_Ticketing;
		this.porta_Ticketing = porta_Ticketing;
		this.ligacao = ligacao;
		try
		{	
			this.in = new BufferedReader (new InputStreamReader(ligacao.getInputStream()));
			
			this.out = new PrintWriter(ligacao.getOutputStream());
		} catch (IOException e) {
			System.out.println("Erro na execucao do servidor: " + e);
			System.exit(1);
		}
	}
	
	public void run() {                
		try {
			System.out.println("Aceitou ligacao de cliente no endereco " + ligacao.getInetAddress() + " na porta " + ligacao.getPort());
			String identificationRaw = in.readLine();
			byte[] md5InBytes = MD5Utils.digest(identificationRaw.getBytes(UTF_8));
			System.out.println(MD5Utils.bytesToHex(md5InBytes));
			out.println(ip_Ticketing + ","+ porta_Ticketing + "," + MD5Utils.bytesToHex(md5InBytes));


			out.flush();
			in.close();
			out.close();
			ligacao.close();

		} catch (IOException e) {
			System.out.println("Erro na execucao do servidor: " + e);
			System.exit(1);
		}
	}
}