%:-dynamic(alojamento/2).
:-dynamic(fact/1).
:-dynamic(variavel/2).
:-dynamic(procurarAlojamento/6).
:-dynamic(retract/3).

%forward chaining

:- op( 800, fx, if).
:- op( 700, xfx, then).
:- op( 300, xfy, or).
:- op( 500, xfy, and).

result:- new_derived_fact(P),             
   !,
   resultadowrite(P), nl,
   assert(fact(P)),
   result.                           
result:- nl,write( 'Esperemos que goste da recomendacao, disfrute') .          

new_derived_fact( Concl)  :-
   if Cond then Concl,               
   \+ fact( Concl),                 
   composed_fact( Cond).             

composed_fact( Cond)  :-
   fact( Cond).                      

composed_fact( Cond1 and Cond2)  :-
   composed_fact( Cond1),
   composed_fact( Cond2).            

composed_fact( Cond1 or Cond2)  :-
   composed_fact( Cond1)
   ;
   composed_fact( Cond2).

%---------    MENU    ----------

menu:- nl,nl , 	write('                                                                                                        '), nl,
				write('                                                                                                        '), nl,
				write('▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀'),nl,nl,
    			write('░░ ░░ ░░ ░░ ░░     '),
    			write('Bᴇᴍ-Vɪɴᴅᴏ ᴀᴏ Assɪsᴛᴇɴᴛᴇ ᴠɪʀᴛᴜᴀʟ ᴅᴀ 🅰🅻🆄🅶🅰     🆄🅼'),
  				write('░░ ░░ ░░ ░░ ░░     '),nl,nl,
				write('▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀'),nl,
				write('                                                                                                        '), nl,
				write('🇵🇷🇦🇿🇪🇷 🇪🇲 🇦🇯🇺🇩🇦-🇱🇴!'),nl,nl,
    			write('🇦🇶🇺🇮 🇵🇴🇩🇪🇷🇦 🇨🇴🇳🇸🇺🇱🇹🇦🇷 🇦🇱🇴🇯🇦🇲🇪🇳🇹🇴🇸 🇵🇷🇴🇽🇮🇲🇴🇸 🇩🇦 🇺🇳🇮🇻🇪🇷🇸🇮🇩🇦🇩🇪 🇩🇴 🇲🇮🇳🇭🇴!'),nl,
       			write('                                                                                                        '), tipo.

tipo:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write('🇵🇷🇪🇹🇪🇳🇩🇪 🇦🇱🇺🇬🇦🇷 🇺🇲 🇶🇺🇦🇷🇹🇴 🇴🇺 🇺🇲 🇦🇵🇦🇷🇹🇦🇲🇪🇳🇹🇴?'), nl,
				write(''), nl,
				write('1- 🇶🇺🇦🇷🇹🇴'), nl,
				write('2- 🇦🇵🇦🇷🇹🇦🇲🇪🇳🇹🇴'), nl,nl,
    			read(C), ( (C == 2), assert(fact(apartamento)), extra; 
                           (C == 1), assert(fact(quarto)), privacy).



privacy:- nl,nl,
    write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,   
    write('🇵🇷🇮🇻🇮🇱🇪🇬🇮🇦 🇦 🇵🇷🇮🇻🇦🇨🇮🇩🇦🇩🇪?'),nl,nl,
    write('1- 🇸🇮🇲'),nl,
    write('2- 🇳🇦🇴'),nl,
    read(P), ( (P == 1), assert(fact(privacidade)), tipologia; 
               (P == 2), assert(fact(n_privacidade)), tipologia).

extra:- nl,nl,
    write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    write('🇶🇺🇪🇷 🇪🇸🇵🇦🇨🇴🇸 🇪🇽🇹🇷🇦?'),nl,nl,
    write('1- 🇸🇮🇲'),nl,
    write('2- 🇳🇦🇴'),nl,
    read(E), ( (E == 1), assert(fact(espacos)), tipologia; 
               (E == 2), assert(fact(n_espacos)), tipologia).

tipologia:- nl,nl,
	    		write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
				write('🇶🇺🇦🇱 🇦 🇹🇮🇵🇴🇱🇴🇬🇮🇦 🇩🇴 🇦🇱🇴🇯🇦🇲🇪🇳🇹🇴 🇶🇺🇪 🇵🇷🇴🇨🇺🇷🇦? (🇪🇽: 🇹1)'), nl,nl,
    			read(T), assert(variavel(tipologia,T)), criterioPreço.

criterioPreço:- nl,nl,
    			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
				write('🇶🇺🇦🇱 🇴 🇵🇷🇪🇨🇴 🇲🇦🇽🇮🇲🇴 🇶🇺🇪 🇵🇷🇪🇹🇪🇳🇩🇪?'), nl,nl,
    			read(Z), assert(variavel(preco,Z)), criterioDistancia.

criterioDistancia:- nl,nl,
				write('🇶🇺🇦🇱 🇦 🇩🇮🇸🇹🇦🇳🇨🇮🇦 🇲🇦🇽🇮🇲🇦 🇦 🇺🇳🇮🇻🇪🇷🇸🇮🇩🇦🇩🇪 🇩🇴 🇲🇮🇳🇭🇴?'), nl,nl,
    			read(D), assert(variavel(distancia,D)), elevador.

elevador:- nl,nl,
    write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,   
    write('🇴 🇦🇱🇴🇯🇦🇲🇪🇳🇹🇴 🇹🇪🇲 🇩🇪 🇮🇳🇨🇱🇺🇮🇷 🇪🇱🇪🇻🇦🇩🇴🇷?'),nl,nl,
    write('1- 🇸🇮🇲'),nl,
    write('2- 🇳🇦🇴'),nl,
    read(E), ( (E == 1), assert(fact(elevador)),resultado; 
              (E == 2), assert(fact(n_elevador)),resultado).

resultado :- 	write('********************************************************************************************************'), nl,
				write('**                                                                                                    **'), nl,			 
				write('**                                         Resultado Obtido                                           **'), nl, 
				write('**                                                                                                    **'), nl,			 
				write('********************************************************************************************************'),
				result.

resultadowrite(P):-	variavel(tipologia,T), variavel(preco,Z), variavel(distancia,D),nl,
					write('     O seu perfil e o'),nl,
					write('     *** '),write(P),write(' ***'),nl,nl,
					write('     Alojamentos aconselhados: '),nl,
    				write('(Tipo, Preço, Distância à UM, Tipologia, Contacto)'),perfil(P,Z,D,T),nl,nl,
					write('********************************************************************************************************'),
					retract(variavel(tipologia,T)), retract(variavel(preco,Z)), retract(variavel(distancia,D)), retractall(fact(_)).


% ------- base de dados --------
%alojamento(tipo,preço(€/mês),distância_UM(km_a_pé),tipologia,dimensao(m2),andar,contacto,[wi_fi,wc_privada,aquecimento,mobilado,partilhado,elevador,espacos extra(ex:garagem)])
%fonte_quartos : https://www.idealista.pt/arrendar-quarto/braga/ 
%fonte_apartamentos : 

alojamento(apartamento,650,0.65,1,100,1, 912566277,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,650,0.25,2,73,2,926384849,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador,espacos]). 
alojamento(apartamento,485,1.3,1,14,3,934563987,[wi_fi,privacidade,aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]). 
alojamento(apartamento,600,1.7,1,55,2,966830379,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,500,0.75,0,40,1,916885145,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]). 
alojamento(apartamento,600,1.4,1,50,2,253686108,[n_wi_fi,n_privacidade,n_aquecimento,n_mobilado,n_partilhado,n_elevador,espacos]). 
alojamento(apartamento,550,0.8,1,59,4,934859230, [n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,espacos]). 
alojamento(apartamento,685,0.8,3,132,2,967045785,[n_wi_fi,privacidade,n_aquecimento,n_mobilado,n_partilhado,n_elevador,espacos]). 
alojamento(apartamento,700,1.2,3,134,1,917502274,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,2500,1.6,4,235,1,917502274,[n_wi_fi,privacidade,aquecimento,mobilado,n_partilhado,elevador,espacos]). 
alojamento(apartamento,350,1.0,0,36,4,910530738,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]). 
alojamento(apartamento,850,1.0,3,140,5,963012695,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,850,1.0,3,140,2,963012695,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,865,0.5,3,156,3,253257703,[n_wi_fi,n_privacidade,n_aquecimento,n_mobilado,n_partilhado,elevador,n_espacos]).
alojamento(apartamento,620,2.6,2,105,2,215561028,[n_wi_fi,n_privacidade,n_aquecimento,n_mobilado,n_partilhado,elevador,espacos]). 
alojamento(apartamento,930,1.2,5,192,1,253257703,[n_wi_fi,n_privacidade,n_aquecimento,n_mobilado,n_partilhado,elevador,n_espacos]).
alojamento(apartamento,485,1.6,1,14,3,966474655,[wi_fi,privacidade,aquecimento,mobilado,partilhado,n_partilhado,n_elevador,espacos]).
alojamento(apartamento,550,0.45,1,59,2,933318006,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,680,1.8,3,102,2,253440453,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,155,0.5,1,100,1,912566277,[n_wi_fi,n_privacidade,n_aquecimento,mobilado,partilhado,n_elevador,espacos]).
alojamento(apartamentos,600,1,1,67,4,253440946,[n_wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,n_elevador,espacos]).
alojamento(apartamento,520,1.2,1,60,1,960067404,[n_wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,elevadorm,n_espacos]).
alojamento(apartamento,520,1.7,1,50,2,253272091,[n_wi_fi,privacidade,aquecimento,mobilado,n_partilhado,elevador,espacos]).
alojamento(apartamento,507,5.3,3,122,3,933318006,[n_wi_fi,privacidade,aquecimento,mobilado,n_partilhado,n_elevador,espacos]).
alojamento(apartamento,500,0.75,0,40,_,960271461,[n_wi_fi,privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador,n_espacos]).
alojamento(apartamento,350,1.1,0,36,_,910575973,[n_wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,elevador,n_espacos]).
alojamento(quarto, 210,3.4,1,60,1,'910575973',[wi_fi,n_privacidade, aquecimento, mobilado, partilhado, elevador]).
alojamento(quarto, 200,2,10,140,1,'960271461',[wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 400,1,3,130,2,'253440371',[wi_fi,privacidade, aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 300,0.25,8,150,6,'967296212',[wi_fi, privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 280,1.3,5,200,1,'910575973',[wi_fi, privacidade,aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 300,1.6,2,102,3,'919000227',[wi_fi,n_privacidade,aquecimento,mobilado,partilhado,elevador]).
alojamento(quarto, 230,0.65,3,90,3,'932350987',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 250,4.8,5,200,2,'933318006',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 250,2.7,4,250,3,'933318006',[wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 300,1.1,3,300,4,'914201091',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).
alojamento(quarto, 275,3.3,4,120,2,'965198665',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 250,1.5,4,200,2,'918105489',[wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 199,1.7,4,150,2,'917922443',[wi_fi,n_privacidade,n_aquecimento,mobilado,partilhado,elevador]).
alojamento(quarto, 175,0.5,3,120,3,'910631002',[wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 250,3.3,1,75,3,'931165647',[wi_fi,n_privacidade,aquecimento,mobilado,partilhado,n_elevador]).
alojamento(quarto, 330,0.35,2,90,3,'919000227',[n_wi_fi,n_privacidade,aquecimento,mobilado,partilhado,elevador]).
alojamento(quarto, 230,1.8,3,300,6,'939760415',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).
alojamento(quarto, 220,2.6,3,120,5,'+4917620350106',[wi_fi,n_privacidade,aquecimento,mobilado,partilhado,elevador]).
alojamento(quarto, 350,0.65,2,80,2,'910575973',[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 250,1.2,5,500,1,'931165647',[wi_fi,privacidade,aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto, 260,3.0,4,100,1,'966474655',[wi_fi,privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]). 
alojamento(quarto, 220,3.0,4,100,1,'966474655',[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]). 
alojamento(quarto, 170,1.4,3,90,6,'969054497',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]). 
alojamento(quarto, 230,1.6,3,90,6,'969054497',[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).
alojamento(quarto,360,8.8,1,280,1,'933777862',[wi_fi,privacidade,aquecimento,mobilado,partilhado,n_elevador]).
alojamento(quarto,300,4.7,1,300,1,'933656603',[wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto,170,4.4,1,100,2,'928153266',[n_wi_fi,n_privacidade,aquecimento,mobilado,partilhado,n_elevador]).           
alojamento(quarto,300,0.55,3,300,1,'925052525',[wi_fi,privacidade,aquecimento,mobilado,partilhado,n_elevador]).
alojamento(quarto,195,2.7,2,110,0,'914209828',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).           
alojamento(quarto,250,0.4,5,120,2,'918105489',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).
alojamento(quarto,385,1.1,2,324,1,'919957931',[wi_fi,n_privacidade,aquecimento,mobilado,partilhado,n_elevador]).           
alojamento(quarto,170,4.4,2,100,2,'928153266',[n_wi_fi,n_privacidade,aquecimento,mobilado,partilhado,n_elevador]).           
alojamento(quarto,320,0.9,3,110,2,'922059156',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).           
alojamento(quarto,230,0.75,3,300,6,'939760415',[wi_fi,privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).           
alojamento(quarto,350,4.2,3,120,3,'918948647',[n_wi_fi,privacidade,n_aquecimento,mobilado,partilhado,n_elevador]).           
alojamento(quarto,220,3.2,3,150,0,'913318213',[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).           
alojamento(quarto,300,1.6,2,100,3,'918948647',[wi_fi,n_privacidade,aquecimento,mobilado,n_partilhado,elevador]).
alojamento(quarto,250,2.4,4,100,2,'918105489',[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).           
alojamento(quarto,200,1.3,4,300,1,'919957931',[n_wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,n_elevador]).           
alojamento(quarto,250,0.85,4,200,3,'963989441',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).           
alojamento(quarto,210,3.1,4,300,0,'966500674',[n_wi_fi,n_privacidade,mobilado,partilhado,n_elevador]).
alojamento(quarto,350,1.6,3,160,1,'915182110',[wi_fi,n_privacidade,aquecimento,mobilado,partilhado,elevador]).           
alojamento(quarto,320,2.6,2,80,1,'915182110',[wi_fi,n_privacidade,n_aquecimento,mobilado,partilhado,elevador]).           
alojamento(quarto,400,1.2,3,60,3,'914201091',[wi_fi,n_privacidade,n_aquecimento,mobilado,n_partilhado,elevador]).           
alojamento(quarto,310,3.1,1,150,1,'966500674',[wi_fi,n_privacidade,n_aquecimento,mobilado,partilhado,n_elevador]).   

%Z=preço; D=distância

perfil(1,Z,D,T):- procurarAlojamento(quarto,elevador,privacidade,Z,D,T).
perfil(2,Z,D,T):- procurarAlojamento(quarto,elevador,n_privacidade,Z,D,T).
perfil(3,Z,D,T):- procurarAlojamento(quarto,n_elevador,privacidade,Z,D,T).
perfil(4,Z,D,T):- procurarAlojamento(quarto,n_elevador,n_privacidade,Z,D,T).
perfil(5,Z,D,T):- procurarAlojamento(apartamento,elevador,espacos,Z,D,T).
perfil(6,Z,D,T):- procurarAlojamento(apartamento,elevador,n_espacos,Z,D,T).
perfil(7,Z,D,T):- procurarAlojamento(apartamento,n_elevador,espacos,Z,D,T).
perfil(8,Z,D,T):- procurarAlojamento(apartamento,n_elevador,n_espacos,Z,D,T).

membro( Z, [Z|_] ).
membro( Z, [_|Y] ) :- membro(Z,Y).

%A tipologia n pode ser <, pq se ele puser t0, n ha menor 
procurarAlojamento(X,Y,W,Z,D,T):- findall((X, P, F, B,C),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, membro(W,U), membro(Y,U) ), K), print(K).

%procurarAlojamento2(X,Y,_,Z,D,T):- findall((B, C, X, P, F),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, \+membro(privacidade,U), membro(Y,U) ), K), print(K).
%procurarAlojamento3(X,_,W,Z,D,T):- findall((B, C, X, P, F),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, membro(W,U), \+membro(elevador,U) ), K), print(K).
%procurarAlojamento4(X,_,_,Z,D,T):- findall((B, C, X, P, F),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, \+membro(privacidade,U), \+membro(elevador,U) ), K), print(K).
%procurarAlojamento5(X,Y,_,Z,D,T):- findall((B, C, X, P, F),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, membro(garagem,U), membro(Y,U) ), K), print(K).
%procurarAlojamento6(X,Y,_,Z,D,T):- findall((B, C, X, P, F),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, \+membro(garagem,U), membro(Y,U) ), K), print(K).
%procurarAlojamento7(X,_,_,Z,D,T):- findall((B, C, X, P, F),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, membro(garagem,U), \+membro(elevador,U) ), K), print(K).
%procurarAlojamento8(X,_,_,Z,D,T):- findall((B, C, X, P, F),(alojamento(X,P,F,B,_,_,C,U),P<Z, F<D, B=<T, \+membro(garagem,U), \+membro(elevador,U) ), K), print(K).


% base_de_conhecimento
%perfis

if quarto and elevador and privacidade then 1.
if quarto and elevador and n_privacidade then 2.
if quarto and n_elevador and privacidade then 3.
if quarto and n_elevador and n_privacidade then 4.
if apartamento and elevador and espacos then 5.
if apartamento and elevador and n_espacos then 6.
if apartamento and n_elevador and espacos then 7.
if apartamento and n_elevador and n_espacos then 8.


