%satisfy
% code by Ivan Bratko, 2011:
:-dynamic(fact/1).

satisfy( Object, Conj)  :-
   \+ ( member( Att = Val, Conj),
         member( Att = ValX, Object),
         ValX \== Val).


%induce_if_then
% Paulo Cortez 2021@
% Figure 20.11  A program that induces if-then rules.
% Learning of simple if-then rules

:-  op( 300, xfx, <==).

% learn( Class): collect learning examples into a list, construct and
% output a description for Class, and assert the corresponding rule about Class

learn( Class)  :-
   bagof( example( ClassX, Obj), example( ClassX, Obj), Examples),        % Collect examples
   learn( Examples, Class, Description),                                  % Induce rule   
   nl,                               % Output rule   
   assert( Class  <==  Description).                                      % Assert rule

% learn( Examples, Class, Description):
%    Description covers exactly the examples of class Class in list Examples

learn( Examples, Class, [])  :-
   \+ member( example( Class, _ ), Examples).               % No example to cover 

learn( Examples, Class, [Conj | Conjs])  :-
   learn_conj( Examples, Class, Conj),
   remove( Examples, Conj, RestExamples),                    % Remove examples that match Conj   
   learn( RestExamples, Class, Conjs).                       % Cover remaining examples 

% learn_conj( Examples, Class, Conj):
%    Conj is a list of attribute values satisfied by some examples of class Class and
%    no other class

learn_conj( Examples, Class, [])  :-
   \+ ( member( example( ClassX, _ ), Examples),            % There is no example
   ClassX \== Class), !.                                     % of different class 

learn_conj( Examples, Class, [Cond | Conds])  :-
   choose_cond( Examples, Class, Cond),                      % Choose attribute value   
   filter( Examples, [ Cond], Examples1),
   learn_conj( Examples1, Class, Conds).

choose_cond( Examples, Class, AttVal)  :-
   findall( AV/Score, score( Examples, Class, AV, Score), AVs),
   best( AVs, AttVal).                                       % Best score attribute value 

best( [ AttVal/_], AttVal).

best( [ AV0/S0, AV1/S1 | AVSlist], AttVal)  :-
   S1  >  S0, !,                                             % AV1 better than AV0   
   best( [AV1/S1 | AVSlist], AttVal)
   ;
   best( [AV0/S0 | AVSlist], AttVal).

% filter( Examples, Condition, Examples1):
%    Examples1 contains elements of Examples that satisfy Condition

filter( Examples, Cond, Examples1)  :-
   findall( example( Class, Obj),
                ( member( example( Class, Obj), Examples), satisfy( Obj, Cond)),
                Examples1).

% remove( Examples, Conj, Examples1):
%    removing from Examples those examples that are covered by Conj gives Examples1

remove( [], _, []).

%remove( [example( Class, Obj) | Es], Conj, Es1)  :-
remove( [example( _, Obj) | Es], Conj, Es1)  :-
   satisfy( Obj, Conj), !,                                    % First example matches Conj   
   remove( Es, Conj, Es1).                                    % Remove it 

remove( [E | Es], Conj, [E | Es1])  :-                        % Retain first example   
   remove( Es, Conj, Es1).

score( Examples, Class, AttVal, Score)  :-
   candidate( Examples, Class, AttVal),          	% A suitable attribute value   
   filter( Examples, [ AttVal], Examples1),      	% Examples1 satisfy condition Att = Val     
   length( Examples1, N1),                       	% Length of list   
   count_pos( Examples1, Class, NPos1),          	% Number of positive examples   
   NPos1 > 0,                                    	% At least one positive example matches AttVal
   Score is (NPos1 + 1) / (N1 + 2).			% Laplace estimate of probability of Class

candidate( Examples, Class, Att = Val)  :-
   attribute( Att, Values),                      	% An attribute   
   member( Val, Values),                         	% A value   
   suitable( Att = Val, Examples, Class).

suitable( AttVal, Examples, Class)  :-            
    % At least one negative example must not match AttVal
   member( example( ClassX, ObjX), Examples),
   ClassX \== Class,                                     % Negative example   
   \+ satisfy( ObjX, [ AttVal]), !.                      % that does not match 

% count_pos( Examples, Class, N):
%    N is the number of positive examples of Class

count_pos( [], _, 0).

count_pos( [example( ClassX,_ ) | Examples], Class, N)  :-
   count_pos( Examples, Class, N1),
   ( ClassX = Class, !, N is N1 + 1; N = N1).

writelist( []).

writelist( [X | L])  :-
   tab( 2), write( X), nl,
   writelist( L).

% classify an object (get the class):
classify(Object,Class):-
	Class <== Description,		% Learned rule about Class
	member(Conj, Description),	% A conjunctive condition
	satisfy(Object, Conj).		% Object satisfies Conj

%alojamento_ifthen
:- dynamic (<== /2).
           
nao<==[[partilhar_espacos=nao, habitos_diferentes=sim],
        [trabalhar_equipa=sozinho, genero=masculino],
        [ambiente=sossegado, ano_universidade=outro], 
      	[ano_universidade=4, ambiente=agitado],
        [ambiente=sossegado,idade=entre18_21]].
           
sim<==[[partilhar_espacos=sim, habitos_diferentes=nao],
        [partilhar_espacos=sim, habitos_diferentes=sim],
        [partilhar_espacos=nao, habitos_diferentes=nao],
       [trabalhar_equipa=equipa, genero=feminino],
        [trabalhar_equipa=equipa, genero=masculino],
        [trabalhar_equipa=sozinho, genero=feminino],
       [ambiente=agitado, ano_universidade=1],
        [ambiente=agitado , ano_universidade=2],
        [ambiente=agitado, ano_universidade=3],
        [ambiente=agitado, ano_universidade=4],
        [ambiente=agitado, ano_universidade=5],
        [ambiente=agitado, ano_universidade=outro],
        [ambiente=sossegado, ano_universidade=1],
        [ambiente=sossegado , ano_universidade=2],
        [ambiente=sossegado, ano_universidade=3],
        [ambiente=sossegado, ano_universidade=4],
        [ambiente=sossegado, ano_universidade=5],
       [ano_universidade=1, ambiente=sossegado],
      	[ano_universidade=2, ambiente=sossegado],
        [ano_universidade=3, ambiente=sossegado],
        [ano_universidade=5, ambiente=sossegado],
        [ano_universidade=outro,ambiente=sossegado], 
      	[ano_universidade=1,ambiente=agitado],
        [ano_universidade=2,ambiente=agitado],
        [ano_universidade=3,ambiente=agitado],
        [ano_universidade=5,ambiente=agitado],
        [ano_universidade=outro,ambiente=agitado],
      [ambiente=agitado, idade=entre22_25],
        [ambiente=agitado, idade=entre26_29],
        [ambiente=agitado, idade=mais30],
        [ambiente=sossegado, idade=entre22_25],
      	[ambiente=sossegado, idade=entre26_29],
      	[ambiente=sossegado, idade=mais30]].

           
           
% the goal is to classify 
learn_rules:-
	learn(nao),  % negative examples
	learn(sim), % positive examples
        % save new rules:
	tell('Alojamentos_ifthen.pl'),
	listing(<==),
	told.

% example of classifying
q1(Class):- classify([partilhar_espacos=nao,habitos_diferentes=sim],Class), 
           write(classify([partilhar_espacos=nao,habitos_diferentes=sim],Class)).
q2(Class):- classify([trabalhar_equipa=sozinho,genero=masculino],Class).
q3(Class):- classify([partilhar_espacos=sim, habitos_diferentes=nao],Class).
q5(Class):- classify([ambiente=agitado,idade=entre22_25,ano_universidade=1,trabalhar_equipa=equipa,genero=feminino], Class).

q4(Class):- findall(A,fact(A),Z), classify(Z,Class), retractall(fact(_)).
       

%interface
menu:- nl,nl , 	write('                                                                                                        '), nl,
				write('                                                                                                        '), nl,
				write('▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀'),nl,nl,
    			write('░░ ░░ ░░ ░░ ░░     '),
    			write(''),
  				write('░░ ░░ ░░ ░░ ░░     '),nl,nl,
				write('▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀'),nl,
				write('                                                                                                        '), nl,
				write('🇵🇷🇦🇿🇪🇷 🇪🇲 🇦🇯🇺🇩🇦-🇱🇴!'),nl,nl,
    			write(''),nl,
       			write('                                                                                                        '), genero.


genero:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write('Qual o seu género?'), nl,
				write(''), nl,
				write('1- Feminino'), nl,
				write('2- Masculino'), nl,nl,
    			read(Genero),
        		((Genero == 1), assert(fact(genero=feminino)),idade;
        		(Genero == 2), assert(fact(genero=masculino)), idade).


idade:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write('Que idade tem?'), nl,
				write(''), nl,
				write('1- entre 18 - 21 anos'), nl,
				write('2- entre 22 - 25 anos'), nl,
                write('3- entre 26 - 29 anos'), nl,
                write('4- mais de 30 anos'), nl,nl,
    			read(Idade),
        		((Idade == 1), assert(fact(idade=entre18_21)), ano;
        		(Idade == 2), assert(fact(idade=entre22_25)), ano;
        		(Idade == 3), assert(fact(idade=entre26_29)), ano;
        		(Idade == 4), assert(fact(idade=mais30)), ano). 
  
ano:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write('Qual o ano que está a frequentar atualmente?'), nl,
				write(''), nl,
				write('1- 1º ano'), nl,
				write('2- 2º ano'), nl,
                write('3- 3º ano'), nl,
                write('4- 4º ano'), nl,
                write('5- 5º ano'), nl,
                write('6- Outro'), nl,nl,
    		    read(Ano),
        		((Ano == 1), assert(fact(ano_universidade=1)), ambiente;
        		(Ano == 2), assert(fact(ano_universidade=2)), ambiente;
        		(Ano == 3), assert(fact(ano_universidade=3)), ambiente;
        		(Ano == 4), assert(fact(ano_universidade=4)), ambiente;
       		 	(Ano == 5), assert(fact(ano_universidade=5)), ambiente;
        		(Ano == 6), assert(fact(ano_universidade=outro)), ambiente).
           
ambiente:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write('Prefere estudar/trablhar num ambiente...'), nl,
				write(''), nl,
				write('1- Onde posso ajudar e ser ajudado/a por pessoas, o ruído não tem grande interferência no meu estudo'), nl,
				write('2- Sossegado, com poucos ou nenhuns estímulos externos (pessoas, ruído, televisão,...)'), nl,nl,
    			read(Ambiente),
        		((Ambiente == 1), assert(fact(ambiente=agitado)),equipa;
        		(Ambiente == 2), assert(fact(ambiente=sossegado)),equipa).
           
           
equipa:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write('Gosta de trabalhar em equipa?'), nl,
				write(''), nl,
				write('1- Sim, gosto de lidar com pessoas, dividir tarefas e responsabilidades'), nl,
				write('2- Não, prefiro trabalhar sozinho/a'), nl,nl,
    			read(Equipa),
        		((Equipa == 1), assert(fact(trabalhar_equipa=equipa)), partilhar;
        		(Equipa == 2), assert(fact(trabalhar_equipa=sozinho)), partilhar).
           
partilhar:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write(' Partilhar espaços ou utensílios que utiliza no seu dia-a-dia (cozinha, WC, sala,...) com desconhecidos...'), nl,
				write(''), nl,
				write('1- Não é um problema, gosto de ter companhia e além disso as responsalidades e encargos financeiros são divididos'), nl,
				write('2- É algo que não gosto, não me sinto à vontade'), nl,nl,
    			read(Espacos),
        		((Espacos == 1), assert(fact(partilhar_espacos=sim)),habitos;
        		(Espacos == 2), assert(fact(partilhar_espacos=nao)),habitos).  

habitos:- nl,nl, 
       			write('​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​'),nl,
    			write('Lidar diariamente com pessoas que têm hábitos e rotinas diferentes das suas, a longo prazo,...'), nl,
				write(''), nl,
				write('1- Considero que seja algo importante, porque me faz crescer'), nl,
				write('2- Tem impacto menos positivo em mim, deixa-me stressado/a'), nl,nl,
    			read(Habitos),
        		((Habitos == 1), assert(fact(habitos_diferentes=sim)), resultado;
        		(Habitos == 2), assert(fact(habitos_diferentes=nao)), resultado). 
           
resultado:-      
				nl,nl,     
				write('RESULTADO'),nl, 
				q4(C),
				write('Alojamento partilhado? '), write(C),nl,nl,
				write("Disfrute da sua estadia! Obrigada!"),nl.
          
           
           

%atributos

:- dynamic attribute/2. 
attribute(genero, [feminino,masculino]).
attribute(idade, [entre18_21, entre22_25, entre26_29, mais30]).
attribute(ano_universidade, [1, 2, 3, 4, 5, outro]).
attribute(ambiente, [agitado,sossegado]).
attribute(trabalhar_equipa, [sozinho, equipa]).
attribute(partilhar_espacos, [sim, nao]).
attribute(habitos_diferentes, [sim, nao]).

           
           