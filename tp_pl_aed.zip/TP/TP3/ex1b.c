#include <stdio.h>

main(){
    int n, i, soma = 0;
    printf("Insira N numeros\n");
    scanf("%d", &n);
    for(i = 1; i <= n; i++){
        soma = soma + i;
    }
    printf("Soma= %d", soma);
}