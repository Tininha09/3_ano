#include <stdio.h>

main(){
    int n, i;
    printf("Insira N numeros\n");
    scanf("%d", &n);
    for(i = 1; i <= n; i++){
        printf("%d", i);
    }

    /*
    i = 1;
    while(i <= n)
    {
        printf("%d", i);
        i++; ou i = i + 1;
    }
    */
}