#include <stdio.h>

main(){
    int n, i;
    printf("Insira 1 numero:\n");
    scanf("%d", &n);
    i = n - 1;
    while(i > 1){
        n *= i;
        i--;
    }
    printf("Fatorial = %d", n);
}