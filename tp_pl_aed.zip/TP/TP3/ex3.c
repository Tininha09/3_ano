#include <stdio.h>

main(){
    int n1, n2;
    char continuar = 's';
    do{
        printf("insira 2 numeros");
        scanf("%d %d", &n1, &n2);
        printf("Valor soma = %d\n", n1 + n2);
        printf("Deseja continuar?\n");
        scanf(" %c", &continuar);
    }while(continuar == 's' || continuar == 'S');
}