#include <stdio.h>

main(){
    int i = 1;
    do{
        printf("%c \n", i);
        i++;
    }
    while(i <= 256);
}