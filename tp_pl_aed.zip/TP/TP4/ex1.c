#include <stdio.h>
#include <stdbool.h>
//EXERCICIO 1
/*bool par(int n){
    return n%2 == 0;
}
*/
int par(int n){
    return n%2 == 0;
}

//EXERCICIO 2
int fatorial(int n){
    int i, fat = n;
    for (i = n-1; i >= 1; i--){
        //fat = fat * i;
        fat *= i;
    }
    return fat;
}

//EXERCICIO 3
float peso_ideal(float alt, char genero){
    if (genero =='m' || genero == 'M')
        return 72.7 * alt - 58;
    else 
        if (genero == 'f' || genero == 'F')
            return 62.1 * alt - 44.7;
    return 0.0; // se nao for nem M ou F, retorna erro
}

//EXERCICIO 4
void tabuada (int N){
    int i;
    printf("\n============================");
    printf("\n        TABUADA DO %d ", N);
    printf("\n============================");

    for ( i=1; i <=10; i++){
        printf ("\n %d x %d ", N , i);
    }
}

//EXERCICIO 5
int maior_de_10(){
    int i, n, maior;
    for(i = 1; i <= 10; i++){
        printf("Insira um número: ");
        scanf("%d", &n);
        if(i==1)
            maior = n;
        else 
            if (n > maior)
                maior = n;
    }
    return maior;
}

//EXERCICIO 6
int n_divisores (int numero){
    int soma_divs = 0, i=1;

    while (i <= numero){
        if (numero%i==0){
            soma_divs++;
        }
        i++;
    }
    return soma_divs;
    
}

//EXERCICIO 7
float serie_ex_7(int N){
    float s;
    int i;
    for (i=1; i<=N; i++){
        s += 1.0/i;
    }
    return s;
}

int main(){
    /* EXERCICO 1
    int meuNum;
    printf("Insira um numero: ");
    scanf("%d", &meuNum);
    int resPar = par(meuNum);
    if (resPar == 0){
        printf("\nNumero impar");
    } else {
        printf("\nNumero par");
    }
    */

    /* EXERCICIO 2
    int meuNum;
    printf("Insira um numero: ");
    scanf("%d", &meuNum);
    int resfatorial = fatorial(meuNum);
    printf("\nFatorial %d = %d", meuNum, resFatorial)
    */

    /* EXERCICIO 3
    float numInserido;
    char genero;
    printf("Insira a altura e genero \n");
    scanf(" %f %c", &numInserido, &genero);
    printf("Peso ideal = %f", peso_ideal(numInserido, genero));
    */

    /* EXERCICIO 4
    int n;
    printf("Introduza um numero: ");
    scanf("%d",&n);
    tabuada(n);
    */

    /* EXERCICIO 5
    int maior = maior_de_10();
    printf("Maior Introduzido: %d", maior)
    */

    /* EXERCICIO 6
    int n=0;
    printf ("Insira um numero: \n");
    scanf("%d", &n);
    int ndiv = n_divisores(n);
    printf("Numero de divisores= %d", ndiv);
    */

    /* EXERCICIO 7
    int num;
    printf("Insira um numero: ");
    scanf("%d", &num);
    printf("Total: %f", serie_ex_7(num));
    */


}