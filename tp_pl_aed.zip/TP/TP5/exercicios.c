#include <stdio.h>

//---------Exercicio 1
int potencia_recursiva(int base, int elevado){
    if (elevado == 0){
        return 1;
    }
    return base * potencia_recursiva(base, elevado-1);
}
//----------

//---------Exercicio 2
int fibonacci(int n) {
    int x;
    if (n == 1) {
        return(1);
    }
    
    if (n == 2) {
        return(1);
    }
    
    x = fibonacci(n-1) + fibonacci(n-2);
    return(x);
}
//------------

//---------Exercicio 4
int preencherArray(int v[], int n){
    int i;
    for(i=0; i<n; i++){
        printf("Insira numero na posicao %d do vetor: ", i);
        scanf("%d", &v[i]);
    }
    return *v;
}

float mediaArray(int v[], int n){
    int i;
    float media = 0;
    for(i=0; i<n; i++){
        media = media + v[i];
    }
    media = media/n;
    return media;
}

float superioresMedia(int v[], float media, int n){
    int i;
    float superiores = 0;
    for(i=0; i<n; i++){
        if(v[i] > media)
            superiores += 1;
    }
    return (superiores*100)/n;
}
//------------

//------------EXERCICIO 5
int ocorrencias(int v[], int n, int elem){
    int i, ocorrencias = 0;
    for(i=0; i<n; i++){
        if(v[i] == elem)
            ocorrencias++;
    }
    return ocorrencias;
}
//--------------

void somarMatrizes(int **a, int **b, int **matriz, int l, int c){
    int i, j;
    for (i = 0; i < l; i++)
        for (j = 0; j < c; j++) 
            matriz[i][j] = a[i][j] + b[i][j];
    }

int main(){
    /* ---------------------EXERCICIO 1
    printf("Potencia recursiva = %d\n", potencia_recursiva(2,2));
    -------------------------*/
    
    /* ---------------------EXERCICIO 2
    int n,i;
    printf("Digite o numero de termos da sequencia de Fibonacci: ");
    scanf("%d", &n);
    while(n <= 0) {
        printf("Numero incorreto. Digite o numero de termos da sequencia: ");
        scanf("%d", &n);
    }
    
    // Para cada i (de 1 a n), calcula e imprime o
    // i-esimo termo da sequencia de Fibonacci.
    
    for (i = 1; i <= n; i++) {
        printf("%d ", fibonacci(i));
    }
    printf("\n");
    ----------------*/

    /* -------------------EXERCICIO 3
    int v[1000], n, i;
    float media = 0;
    float superioresMedia = 0;

    printf("Quantos numeros deseja introduzir:");
    scanf("%d", &n);

    for(i=0; i<n; i++){
        printf("Insira numero na posicao %d do vetor: ", i);
        scanf("%d", &v[i]);
        media += v[i];
    }
     
    media = media/n;
    printf("\n Media = %f", media);

    for(i=0; i<n; i++){
        if(v[i] > media)
            superioresMedia += 1;
            
    }

    printf("\n%f porcento dos valores sao superiores a media (%f)",(superioresMedia*100)/n, media);

    return 0;
    --------------------------*/

    /* -----------------------EXERCICIO 4
    int v[1000], n, i;
    float media = 0;

    printf("Quantos numeros deseja introduzir:");
    scanf("%d", &n);

    preencherArray(v, n);
    media = mediaArray(v, n);
    printf("\n Media = %f", media);

    printf("\n%f porcento dos valores sao superiores a media ",superioresMedia(v, media, n));

    return 0;
    --------------------------*/
    
    /* -------------------------EXERCICIO 5
    int v[1000], n, i;

    printf("Quantos numeros deseja introduzir:");
    scanf("%d", &n);

    for(i=0; i<n; i++){
        printf("Insira numero na posicao %d do vetor: ", i);
        scanf("%d", &v[i]);
    }
    printf("Ocorrecias de 5: %d", ocorrencias(v, n, 5));
    ---------------------------*/

    /*-----------------------------EXERCICIO 6
    // 3 linhas e 2 colunas
    float matriz[3][2];
    int linha, coluna;
    float soma;
    int i=0;
    for(linha=0; linha<3; linha++){
        for(coluna=0; coluna<2; coluna++){
            printf("Insira numero na linha %d coluna %d do vetor: ", linha, coluna);
            scanf("%f", &matriz[linha][coluna]);
        }
    }

    for(linha=0; linha<3; linha++){
        soma = 0;
        for(coluna=0; coluna<2; coluna++){
            soma = soma + matriz[linha][coluna];
        }
        printf("Soma da linha %d = %f; ", linha, soma);
    }
    ---------------------------*/


}