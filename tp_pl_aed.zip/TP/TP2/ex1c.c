#include <stdio.h>

int main()
{
    float c, f;
    printf("Introduza o valor em graus celsius");
    scanf("%f", &c);
    f = 1.8 * c + 32;
    printf("%f em Fahn = %f", c, f);
    return 0;
}