#include <stdio.h>

int main()
{
    int h, m, s, totalSegundos;
    printf("Insira tempo em h, m, s: \n");
    scanf("%d, %d, %d", &h, &m, &s);
    totalSegundos = h * 3600 + m * 60 + s;
    printf("Passaram %d segundos, considerando o tempo dado.", totalSegundos);
    return 0;
}