#include <stdio.h>

main(){
    float media;
    int a, b, c;
    printf("Insira 3 notas");
    scanf("%d, %d, %d", &a, &b, &c);
    media = (a + b + c)/3;
    if (media >= 9.5)
        printf("Aprovado");
    else 
        printf("Reprovado");
}