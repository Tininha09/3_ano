#include <stdio.h>

int main()
{
    float a, b, A, P;
    printf("Insira dados");
    scanf("%f, %f", &a, &b);
    A = a * b;
    P = 2 * (a + b);
    printf("Area = %f e perímetro = %f", A, P);
    return 0;
}