#include <stdio.h>

int main()
{
    float n1, n2, soma;
    printf("Insira um número: \n");
    scanf("%f", &n1);
    printf("Insira outro número: \n");
    scanf("%f", &n2);
    soma = n1 + n2;
    printf("O resultado é %f", soma);
    return 0;
}