#include<stdio.h>
#include"complexidade.h"

int pesqSeq(int v[], int N, int pesq)
{
	conta_reset();
	int i;
	for(i=0;i<N;i++)
	{
		conta_maismais();
		if(v[i] == pesq)
		{
			return i;
		}
	}
	return -1;
}

void bubleSort(int v[], int n)
{
	int i,j;
	for(i=1;i<n;i++)
	{
		for (j=0;j<n-1;j++)
		{
			if (v[j]>v[j+1])
			{
				int aux = v[j];
				v[j] = v[j+1];
				v[j+1] = aux;
			}
		}
	}
}

int BinarySearch(int v[], int n, int x) //s� funciona para vetores ordenados
{
	conta_reset();
	int left = 0, right = n - 1;
	int middle;
	while (left <= right)
	{
		conta_maismais();
		middle = (left + right) / 2;
		if (x == v[middle]) return middle; /* encontrou */
			else if (x > v[middle]) left = middle + 1;
			else right = middle - 1;
	}
	return -1; /* n�o encontrou */
}

main()
{
	int v[100000];
	int N = 50000;
	int pesq = 111; 
	preenche_random(v,N); //Sorteia valores para o vetor de 1 a 100
	
	//////////////////////////////////MEDI��O COMPLEXIDADE PESQ SEQUENCIAL
	start_clock();
	int res = pesqSeq(v, N, pesq);
	conta_print("PESQUISA SEQUENCIAL");
	stop_clock();
	
	bubleSort(v,N);
	/////////////////////////////////MEDI��O COMPLEXIDADE PESQ BINARIA
	start_clock();
	res = BinarySearch(v, N, pesq);
	conta_print("PESQUISA BIN�RIA");
	stop_clock();

		
}

