#include <stdio.h>
#include "complexidade.h"   //inclui funções de tempo

int pesqSeq(int v[], int N, int pesq)
{
    int i;
    for(i=0;i<N;i++){
        if(v[i] == pesq){
            return i;
        }
    }
    return -1;
}
//ACABAR
void bubleSort(int v[]){  //algortimo de ordenação que faz com que os maiores números "borbulhem" para cima, com comparação 2 a 2
    int i,j;
    for(i=0; i<n-1; i++){
        for(j=0; j<n-1; j++){
            if(v[j]>v[j+1]{
                int aux = v[j];
                v[j] = v[j+1];
                v[j+1] = aux;
            })
        }
    }
}

int BinarySearch(int v[], int n, int x)   //so funciona para vetores ordenados
{
    conta_reset();
    int left = 0, right = n - 1;
    int middle;
    while (left <= right)
    {
        conta_maismais();
        middle = (left + right) / 2;
        if (x == v[middle]) return middle; /* encontrou */ 
        else if (x > v[middle]) left = middle + 1;
        else right = middle - 1;
    }
    return -1; /* não encontrou */ 
}


main(){
    int v[1000];
    int N = 0;
    int pesq = 10;
    //start_clock();
    preenche_random(v, N);
    //bubleSort(v,N);
    //print_vetor(v, N);
    //stop_clock();

    //////////////////////////MEDIÇÃO COMPLEXIDADE PESQ SEQUENCIAL
    start_clock();
    int res = pesqSeq(v,N,pesq);
    conta_print("PESQUISA SEQUENCIAL")
    stop_clock();
    //printf("Valor %d encontradi na posicao %d", pesq, res);

    bubleSort(v,N); //o vetor tem de estar ordenado
    //////////////////////////MEDIÇÃO COMPLEXIDADE PESQ BINARIA
    start_clock();
    res = BinarySearch(v,N,pesq);
    conta_print("PESQUISA BINÁRIA")
    stop_clock();
    

}