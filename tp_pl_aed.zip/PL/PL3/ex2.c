#include <stdio.h>
#include <string.h>

int main(){
    char *__letra;
    while(!strcmp(__letra, "a")){
        printf("Introduza a Letra a: \n");
        scanf("‰c", &__letra);
        //printf("%c", letra);
    } 
}