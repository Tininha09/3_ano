#include <stdio.h>

int main(){
    int n, i=0, somaP=0, somaI=0;
    do{
        printf("Insira numero:\n");
        scanf("%d", &n);
        if(n >= 0){
            if(n % 2 == 0){
                somaP++;
            }else {
                somaI++;
            }
        }
    } while(n > 0);
    printf("Total pares: %d;\n Total impares: %d", somaP, somaI);

}