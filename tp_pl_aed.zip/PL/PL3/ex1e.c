#include <stdio.h>

int main(){
    int n, i, y;
    printf("Qual a dimenção do triangulo?\n");
    scanf("%d", &n);
    for(i=0; i<n; i++){
        for(y= 0; y<=i; y++){
        printf("*");
        }
        printf("\n");
    }
}