#include <stdio.h>

int main(){
    int nc, n, i=0, maior=0, menor=0;

    printf("Quantos numeros pretende inserir?\n");
    scanf("%d", &nc);
    while(i<nc){
        i++;
        printf("Insira numero positivo:\n");
        scanf("%d", &n);
        if(n>= maior){
            maior = n;
        }
        if(n<= menor || menor == 0){
            menor = n;
        }
    }
    printf("O maior é %d, e o menor é %d", maior, menor);

}