#include <stdio.h>

int main(){
    int i, n;
    n = 0;
    for(i=0; n<=20; i++){
        if(i%3 == 0){
            n++;
            printf("%d", i);
        }
    }

}