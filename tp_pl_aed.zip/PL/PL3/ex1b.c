#include <stdio.h>
#include <math.h>

int main(){
    int i, n, soma = 0;

    for(i=0; i<=10; i++){
        printf("Insira um numero positivo: \n");
        scanf("%d", &n);
        if(sqrt(n) > 5){
            soma = soma + n;
        }
    }
    printf("Soma= %d", soma);
}