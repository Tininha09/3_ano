#include <stdio.h>

int main()
{
    int n1, n2, n3, soma2Maiores;
    printf("Insira n1 número: \n ");
    scanf("%d", &n1);
    printf("Insira n2 número: \n ");
    scanf("%d", &n2);
    printf("Insira n3 número: \n ");
    scanf("%d", &n3);
    if (n1 >= n2 && n2 >= n3)
        soma2Maiores = n1 + n2;
    else
       if (n1 >= n2 && n3 >= n2)
            soma2Maiores = n1 + n3;
        else 
            if (n2 >= n1 && n3 >= n1)
                soma2Maiores = n2 + n3;
    printf("Soma do 2 maiores números = %d ", soma2Maiores);
    return 0;
}