#include <stdio.h>
#include <math.h>

int main()
{
    float cateto1, cateto2, n3;
    float hipotenusa, perimetro, area;
    printf("Insira o cateto1: \n ");
    scanf("%f", &cateto1);
    printf("Insira cateto2: \n ");
    scanf("%f", &cateto2);
    hipotenusa = sqrt(pow(cateto1, 2) + pow(cateto2, 2));
    perimetro = cateto1 + cateto2 + hipotenusa;
    area = (cateto1 * cateto2) / 2;
    printf("Hipotenusa = %f ", hipotenusa);
    printf("Permetro = %f ", perimetro);
    printf("Area = %f", area);
    return 0;
}