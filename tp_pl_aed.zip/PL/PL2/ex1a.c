#include <stdio.h>

int main()
{
    float n1, n2, n3;
    float media;
    printf("Insira n1 número: \n ");
    scanf("%f", &n1);
    printf("Insira n2 número: \n ");
    scanf("%f", &n2);
    printf("Insira n3 número: \n ");
    scanf("%f", &n3);
    media = (n1 + n2 + n3) / 3;
    printf("Media aritmédica do 3 números = %f ", media);
    return 0;
}