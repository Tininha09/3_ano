#include <stdio.h>

int main()
{
    float milhas, km;
    printf("Insira a distância em milhas: \n ");
    scanf("%f", &milhas);
    km = milhas / 1.609;
    printf("São %f km: ", km);
    return 0;
}