#include <stdio.h>

int main()
{
    int n1, n2, n3, maior;
    printf("Insira n1 número: \n ");
    scanf("%d", &n1);
    printf("Insira n2 número: \n ");
    scanf("%d", &n2);
    printf("Insira n3 número: \n ");
    scanf("%d", &n3);
    if (n1 >= n2)
        maior = n1;
    else
       if (n2 >= n3)
            maior = n2;
        else 
            maior = n3;
    printf("Valor do maior dos 3 números = %d ", maior);
    return 0;
}