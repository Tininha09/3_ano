#include <stdio.h>

int main()
{
    int n1;
    printf("Insira n1 número: \n ");
    scanf("%d", &n1);

    if (n1 % 2 == 0)
        printf ("\nO Número é par e");
    else 
        printf("\nO Número é impar e");
    if (n1 < 0)
        printf (" é negativo");
    else 
        printf(" é positivo.");
    return 0;
}