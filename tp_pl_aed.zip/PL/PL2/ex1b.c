#include <stdio.h>

int main()
{
    int minutos, horaCorrente, minutosCorrente;
    printf("Insira o número de minutos decorridos desde o início do dia: \n ");
    scanf("%d", &minutos);
    horaCorrente = minutos/60;
    minutosCorrente = minutos%60;
    printf("São %d horas e %d minutos.", horaCorrente, minutosCorrente);
    return 0;
}