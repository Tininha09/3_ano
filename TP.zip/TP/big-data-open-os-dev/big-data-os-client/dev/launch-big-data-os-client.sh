#!/bin/sh

docker run -it --name big-data-os-client --network hadoop -p 4040:4040 big-data-os-client