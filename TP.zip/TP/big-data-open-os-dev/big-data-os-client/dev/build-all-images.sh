#!/bin/sh

docker build . -f big-data-os-client/big-data-os-client.Dockerfile -t big-data-os-client:latest