#!/bin/sh

export HADOOP_CONF_DIR=${SPARK_HOME}/conf/hadoop
export YARN_CONF_DIR=${SPARK_HOME}/conf/hadoop