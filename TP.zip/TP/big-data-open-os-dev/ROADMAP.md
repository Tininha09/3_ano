# Roadmap
- Evaluate the migration of Yarn Timeline Service from V1.5 to V2
- Simplify journey to deploy new cluster, by eliminating the need to manually execute job based on init-big-data-os.yaml
- Develop a way of avoiding secrets in plain text configuration files
- Enable Presto
- Enable Hue, Zeppelin and Jupyter
- Enable Druid